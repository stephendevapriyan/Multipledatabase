package com.example.Multipledatabse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultipledatabseApplicationTests {

	@Test
	void contextLoads() {
	}

}
